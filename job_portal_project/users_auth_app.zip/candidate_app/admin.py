from django.contrib import admin
from . import models

admin.site.register(models.candidateProfileModel)
admin.site.register(models.jobApplicationModel)