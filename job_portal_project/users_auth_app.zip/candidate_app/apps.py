from django.apps import AppConfig


class CandidateAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'candidate_app'
